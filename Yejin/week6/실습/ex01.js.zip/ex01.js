document.getElementById("blockBtn").onclick = function () {
  //디스플레이 속성 변경
  document.getElementById("lion").style.display = "block";
};

document.getElementById("noneBtn").onclick = function () {
  //디스플레이 속성 변경
  document.getElementById("lion").style.display = "none";
};

document.getElementById("colorBtn").onclick = function () {
  //컬러값 저장
  var color = document.getElementById("color").value;

  //저장한 컬러값으로 스타일 변경
  document.body.style.backgroundColor = color;
};

var id = 0;

document.getElementById("submit").onclick = function submit() {
  //입력 값을 양식에 맞춰 출력하기 위해 추후 요소에 들어갈 컨텐츠 생성
  const content =
    "id: " + ++id + ", content: " + document.getElementById("text").value;

  //div안에 적재할 p요소 생성
  const item = document.createElement("p");
  //p 요소 안에 컨텐츠 적재
  item.innerHTML = content;
  //p 요소 스타일 지정
  item.style.backgroundColor = "orange";

  //div요소에 p요소를 추가하기 위해 불러오기
  const parent = document.getElementById("parent");

  //div요소에 p요소 추가
  parent.appendChild(item);

  // document.getElementById("text").value = "";
};
